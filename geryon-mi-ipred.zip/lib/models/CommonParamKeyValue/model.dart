class CommonParamKeyValueCapableModel {}
